"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
// src/authorizer.ts
const aws_jwt_verify_1 = require("aws-jwt-verify");
/**
 * Env
 */
const issuer = process.env.AUTH0_ISSUER_BASE_URL ?? "";
const audience = process.env.AUTH0_AUDIENCE ?? "";
const jwksUri = `${issuer.replace(/\/$/, "")}/.well-known/jwks.json`;
// verifier
const verifier = aws_jwt_verify_1.JwtVerifier.create({
    issuer,
    audience,
    jwksUri,
});
/**
 * Extract Bearer token from "Bearer <token>"
 */
function getBearerToken(authHeader) {
    if (!authHeader || typeof authHeader !== "string")
        return null;
    const parts = authHeader.split(" ");
    if (parts.length !== 2)
        return null;
    const [scheme, token] = parts;
    if (scheme?.toLowerCase() !== "bearer")
        return null;
    return token;
}
/**
 * REQUIRED: Standard REST API IAM policy generator
 */
function generatePolicy(principalId, effect, resource, context = {}) {
    return {
        principalId,
        policyDocument: {
            Version: "2012-10-17",
            Statement: [
                {
                    Action: "execute-api:Invoke",
                    Effect: effect,
                    Resource: resource,
                },
            ],
        },
        context,
    };
}
/**
 * MAIN HANDLER — rewritten for REST API V1 authorizers
 */
const handler = async (event) => {
    try {
        const token = getBearerToken(event.authorizationToken);
        if (!token) {
            return generatePolicy("unauthorized", "Deny", event.methodArn);
        }
        const payload = await verifier.verify(token);
        return generatePolicy(payload.sub || "client", "Allow", event.methodArn.replace(/\/[^/]+$/, "/*"), {
            sub: String(payload.sub ?? ""),
            aud: Array.isArray(payload.aud)
                ? payload.aud.join(",")
                : String(payload.aud ?? ""),
            iss: String(payload.iss ?? ""),
            scope: String(payload.scope ?? ""),
        });
    }
    catch (err) {
        console.error("Auth error:", err);
        return generatePolicy("unauthorized", "Deny", event.methodArn);
    }
};
exports.handler = handler;
//# sourceMappingURL=authorizer.js.map